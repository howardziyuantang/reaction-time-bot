import java.awt.*;
import java.awt.event.InputEvent;
import java.awt.image.BufferedImage;

public class Main {

    private static Robot bot;

    public static void main(String[] args) throws AWTException {

        bot = new Robot();
//        bot.delay(3000);
        click(904, 843);
        click(906, 20);
//        click(821,568);
        click(745,386);
        for(int i = 0; i < 5; i++) {
            while(true) {
                if(bot.createScreenCapture(new Rectangle(745,386,1,1)).getRGB(0,0)==-11805846) {
                    click();
                    break;
                }
            }
            bot.delay(500);
            click();
        }
//        System.out.println(MouseInfo.getPointerInfo().getLocation());

    }

    public static void click(int x, int y) {
        bot.delay(500);
        bot.mouseMove(x,y);
        bot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        bot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
    }

    public static void click() {
        bot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        bot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
    }

}
